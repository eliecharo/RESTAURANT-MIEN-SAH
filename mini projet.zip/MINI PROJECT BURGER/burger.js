let PrimButton=document.getElementsById(Primo) 



PrimButton.addEventlistener('click', function(){
    console.log('DATA DATA DATA')
    })